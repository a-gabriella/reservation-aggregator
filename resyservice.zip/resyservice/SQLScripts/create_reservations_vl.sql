USE rez;

DROP TABLE IF EXISTS `rez`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE rez (
  restaurant_id integer NOT NULL AUTO_INCREMENT,
  restaurant varchar(25) DEFAULT NULL,
  address varchar(50) DEFAULT NULL,
  available_oct_29_2021_6_pm varchar(5) DEFAULT NULL,
  PRIMARY KEY (restaurant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

INSERT INTO user (restaurant, address, available_oct_29_2021_6_pm) VALUES ('Sushi Inoue', '81A Malcolm X Blvd, New York, NY 10027', '1'),
                                                                     ('Sushi Noz', '181 E 78th St New York, NY 10075', '1'),
                                                                     ('Casa Enrique', '5-48 49th Ave Long Island City, NY 11101', '0'),
                                                                     ('Le Jardinier', '610 Lexington Ave New York, NY 10022', '0');