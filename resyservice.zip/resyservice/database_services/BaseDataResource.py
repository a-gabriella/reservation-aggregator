from abc import ABC, abstractmethod


class BaseDataException:

    def __init__(self):
        pass


class BaseDataResource(ABC):

    def __init__(self):
        pass
