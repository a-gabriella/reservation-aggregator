from database_services.RDBService import RDBService


class RezRDBService(RDBService):

    def __init__(self):
        pass

    @classmethod
    def get_reservations(cls, template):

        wc, args = RDBService.get_where_clause_args(template)
        sql = "select * from [carrrie add db]"

        res = RDBService.run_sql(sql, args, fetch=True)
        return res

