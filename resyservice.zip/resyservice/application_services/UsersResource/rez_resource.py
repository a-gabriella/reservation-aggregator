from application_services.BaseApplicationResource import BaseRDBApplicationResource
import database_services.RDBService as d_service


class RezResource(BaseRDBApplicationResource):

    db_name = "[CARRIE ADD HERE]"
    table_name = "rez"

    def __init__(self):
        super().__init__()

    @classmethod
    def get_by_template(cls, template): #in the future this will be lat and long instead of adress
        res = d_service.RDBService.find_by_template("address", "rez",
                                                    template, None)
        return res

    @classmethod
    def get_by_primarykey(cls, key): #in the future this will be lat and long
        template = {"address":key}
        res = d_service.RDBService.find_by_template("address", "rez",
                                                    template, None)
        return res

    @classmethod
    def get_links(self, resource_data):
        pass

    @classmethod
    def get_data_resource_info(cls):
        return '[CARRIE ADD HERE]', 'rez'
